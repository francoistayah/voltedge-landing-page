import React from 'react';

export default function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', backgroundColor: '#000', color: '#fff', padding: '20px' }}>
      <header style={{ textAlign: 'center', paddingBottom: '20px' }}>
        <h1 style={{ color: '#f97316', fontSize: '2.5rem' }}>VoltEdge</h1>
        <p>Power Anywhere, Anytime / الطاقة في أي مكان وأي وقت</p>
      </header>

      <section style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '20px' }}>
        <img src="/solar-power-bank.png" alt="VoltEdge Solar Power Bank" style={{ maxWidth: '300px', marginBottom: '20px' }} />
        <h2 style={{ fontSize: '1.5rem' }}>Your Backup Power for Every Blackout</h2>
        <p style={{ maxWidth: '600px', textAlign: 'center', margin: '20px 0' }}>
          VoltEdge is a 30,000mAh Solar Power Bank built for Lebanon’s energy crisis. Charge your phone, tablet, and router anytime — even with the sun.
          بنك الطاقة VoltEdge جاهز لمساعدتك أثناء انقطاع الكهرباء في لبنان.
        </p>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li>✅ Solar + USB Charging</li>
          <li>✅ Charge 3 Devices at Once</li>
          <li>✅ Water-Resistant & Durable</li>
          <li>✅ Built-in Flashlight</li>
        </ul>
        <a href="https://wa.me/96170000000" style={{
          marginTop: '30px',
          backgroundColor: '#f97316',
          color: '#fff',
          padding: '15px 30px',
          borderRadius: '8px',
          textDecoration: 'none',
          fontWeight: 'bold'
        }}>
          Order via WhatsApp / اطلب عبر واتساب
        </a>
      </section>

      <footer style={{ textAlign: 'center', paddingTop: '40px', fontSize: '0.8rem' }}>
        &copy; 2025 VoltEdge. All rights reserved. / جميع الحقوق محفوظة
      </footer>
    </div>
  );
}